package com.example.me.tapexample.data.tapData;

import java.util.List;

/**
 * Created by Me on 10/16/2015.
 */
public class Tap2Data {
    private String category;
    private String language;
    private List<String> languages;

    public Tap2Data() {
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public List<String> getLanguages() {
        return languages;
    }

    public void setLanguages(List<String> languages) {
        this.languages = languages;
    }
}
