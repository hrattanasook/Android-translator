package com.example.me.tapexample;

/**
 * Created by Me on 10/17/2015.
 */
public interface ITab {

    void refresh();
}
