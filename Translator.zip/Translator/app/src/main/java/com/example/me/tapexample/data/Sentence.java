package com.example.me.tapexample.data;

/**
 * Created by Me on 9/30/2015.
 */
public class Sentence {
    int id;
    String language;
    String category;
    String original;
    String translated;

    public Sentence() {}
    public Sentence(String lan, String cat, String ori, String tra) {
        this.language = lan;
        this.category = cat;
        this.original = ori;
        this.translated = tra;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getOriginal() {
        return original;
    }

    public void setOriginal(String text) {
        this.original = text;
    }

    public String getTranslated () { return translated; }

    public void setTranslated (String text) { this.translated = text; }
}
