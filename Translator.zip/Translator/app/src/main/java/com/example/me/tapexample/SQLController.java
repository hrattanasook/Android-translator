package com.example.me.tapexample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.sql.SQLException;

/**
 * Created by Me on 10/2/2015.
 */
public class SQLController {
    private DatabaseHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public SQLController (Context c) {
        context = c;
    }

    public SQLController open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public void insert( String lan, String cat, String ori, String tra ) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.KEY_LANGUAGE, lan);
        contentValue.put(DatabaseHelper.KEY_CATEGORY, cat);
        contentValue.put(DatabaseHelper.KEY_ORIGINAL, ori);
        contentValue.put(DatabaseHelper.KEY_CATEGORY, tra);
        database.insert(DatabaseHelper.TABLE_SENTENCE, null, contentValue);
    }

    public Cursor fetch() {
        String[] columns = new String[] { DatabaseHelper.KEY_ID,
                DatabaseHelper.KEY_LANGUAGE,
                DatabaseHelper.KEY_CATEGORY,
                DatabaseHelper.KEY_ORIGINAL,
                DatabaseHelper.KEY_TRANSLATE };
        Cursor cursor = database.query(DatabaseHelper.TABLE_SENTENCE, columns, null,
                null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }
    public int update(int id, String lan, String cat, String ori, String tra) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.KEY_LANGUAGE, lan);
        contentValue.put(DatabaseHelper.KEY_CATEGORY, cat);
        contentValue.put(DatabaseHelper.KEY_ORIGINAL, ori);
        contentValue.put(DatabaseHelper.KEY_CATEGORY, tra);
        int i = database.update(DatabaseHelper.TABLE_SENTENCE, contentValue,
                DatabaseHelper.KEY_ID + " = " + id, null);
        return i;
    }
    public void delete(int id) {
        database.delete(DatabaseHelper.TABLE_SENTENCE, DatabaseHelper.KEY_ID + "=" + id, null);
    }
}
