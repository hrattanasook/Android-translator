package com.example.me.tapexample;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.me.tapexample.data.Sentence;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Me on 9/24/2015.
 */
public class Tap3 extends Fragment implements ITab {
    private Spinner langSpn;
    private EditText categoryEdt;
    private EditText origiEdt;
    private EditText tranEdt;
    private TextView origiWarningTxtVw;
    private TextView transWarningTxtVw;
    private Button saveBtn;
    private Button deleteBtn;
    private ListView listView_t2;
    private List<Sentence> sentences = new ArrayList<Sentence>();
    private DatabaseHelper dbh;
    private int indexselected;
    private Context context;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.tab_3,container,false);
        langSpn = (Spinner)v.findViewById(R.id.spnLanguage);
        categoryEdt = (EditText)v.findViewById(R.id.editTextCategory);
        origiEdt = (EditText)v.findViewById(R.id.editTextOrg);
        tranEdt = (EditText)v.findViewById(R.id.editTextTrans);
        saveBtn = (Button)v.findViewById(R.id.saveBtn);
        deleteBtn = (Button)v.findViewById(R.id.deleteBtn);
        listView_t2 = (ListView)v.findViewById(R.id.listView);
        context = this.getContext();
        origiWarningTxtVw = (TextView)v.findViewById(R.id.origiWarningTxtVw);
        transWarningTxtVw = (TextView)v.findViewById(R.id.tranlatedWanningTxtVw);

        dbh = new DatabaseHelper(context);

        this.loadLangToSpinner();
        this.spinnerClicked();
        this.addBtnClicked();
        this.listViewClick();
        this.deleteBtnClick();
        this.clearWarningOrigi();
        this.clearWarningTrans();
        return v;
    }

    @Override
    public void refresh() { }

    private  void listViewClick () {
        listView_t2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                view.setSelected(true);
                Sentence tempS = sentences.get(position);
                indexselected = tempS.getId();
                showInfoSelected(tempS);
            }
        });
    }

    private void showInfoSelected(Sentence s) {
        langSpn.setSelection(getLangSpnIndex(s.getLanguage()));
        categoryEdt.setText(s.getCategory());
        origiEdt.setText(s.getOriginal());
        tranEdt.setText(s.getTranslated());
    }

    private int getLangSpnIndex(String langStr) {
        int t = langSpn.getAdapter().getCount();
        for(int i = 0; i < t; i++) {
            String langTemp = langSpn.getItemAtPosition(i).toString();
            boolean isEqual = langTemp.equalsIgnoreCase(langStr);
            if (isEqual) {
                return i;
            }
        }
        return 0;
    }

    private  void deleteBtnClick() {
        deleteBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);

                // Setting Dialog Title
                alertDialog.setTitle("Confirm Delete Data");
                // Setting Dialog Message
                alertDialog.setMessage("Are you sure you want delete this?");
                // Setting Icon to Dialog
                alertDialog.setIcon(R.drawable.delete);
                // Setting Positive "Yes" Button
                alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int which) {
                        dbh.remove(indexselected);
                        clearText();
                        loadListViewBylan(langSpn.getSelectedItem().toString());
                        Toast.makeText(context, "Data is DELETED", Toast.LENGTH_SHORT).show();
                    }
                });
                // Setting Negative "NO" Button
                alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Write your code here to invoke NO event
                        Toast.makeText(context, "You clicked on NO", Toast.LENGTH_SHORT).show();
                        dialog.cancel();
                    }
                });
                // Showing Alert Message
                alertDialog.show();//.getWindow().setLayout(600,500);
            }
        });
    }

    private void addBtnClicked () {

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String lan = langSpn.getSelectedItem().toString();
                final String cat = categoryEdt.getText().toString();
                final String ori = origiEdt.getText().toString();
                final String tra = tranEdt.getText().toString();
                Sentence s = new Sentence(lan, cat, ori, tra);
                if (is2TxtbxEmpty()) {
                    String str = "Please fill in the data";
                    setWarningTxt(str);
                } else {
                    if (!dbh.exists(s)) {
                        dbh.addSentence(new Sentence(lan, cat, ori, tra));
                        clearText();
                        Toast.makeText(context, "Data are ADDED", Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(context, "Data already EXIST", Toast.LENGTH_SHORT).show();
                        clearText();
                    }
                }
                loadListViewBylan(langSpn.getSelectedItem().toString());
            }
        });
    }

    private  void loadListViewBylan(String lan) {
        sentences = dbh.getSentencesByLan(lan);
        ArrayList<String> list = new ArrayList<String>();
        final HashMap<Integer, String> translatedText = new HashMap<>();
        for (int i = 0; i < sentences.size(); i++) {
            Sentence s = sentences.get(i);
            translatedText.put(i, s.getTranslated());
            list.add(s.getOriginal());
        }
        StableArrayAdapter adapter = new StableArrayAdapter(this.getActivity(),
                android.R.layout.simple_list_item_1, list);
        listView_t2.setAdapter(adapter);
    }

    private void spinnerClicked() {
        langSpn.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadListViewBylan(langSpn.getSelectedItem().toString());
                //Toast.makeText(context, "Language is select", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void loadLangToSpinner() {
        List<String> langFrDB = dbh.getAllLanguages();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_spinner_item,langFrDB);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        langSpn.setAdapter(dataAdapter);
    }

    private void clearText() {
        categoryEdt.setText("");
        origiEdt.setText("");
        tranEdt.setText("");
    }

    private void setWarningTxt(String str) {
        origiWarningTxtVw.setText(str);
        transWarningTxtVw.setText(str);
        origiWarningTxtVw.setTextColor(Color.RED);
        transWarningTxtVw.setTextColor(Color.RED);
    }
    
    private void clearWarningOrigi() {
        origiEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                origiWarningTxtVw.setText("");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void clearWarningTrans() {
        tranEdt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                transWarningTxtVw.setText("");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private boolean is2TxtbxEmpty() {
        return origiEdt.getText().toString().isEmpty() && tranEdt.getText().toString().isEmpty() ;
    }
}
