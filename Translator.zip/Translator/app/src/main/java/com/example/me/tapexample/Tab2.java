package com.example.me.tapexample;

/**
 * Created by Me on 9/23/2015.
 */
import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.me.tapexample.data.tapData.Tap2Data;
import com.example.me.tapexample.data.Sentence;
import com.example.me.tapexample.data.Sentences;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Created by hp1 on 21-01-2015.
 */
public class Tab2 extends Fragment implements ITab {
    private Spinner language;
    private Spinner category;
    private ListView listView;
    private TextView outputTxt;
    private Button speakBtn;
    private TextToSpeech tts;
    private Context context;
    public DatabaseHelper dbh;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.tab_2,container,false);
        context = getActivity();
        category = (Spinner)v.findViewById(R.id.category);
        language = (Spinner)v.findViewById(R.id.language);
        listView = (ListView)v.findViewById(R.id.listView);
        outputTxt = (TextView)v.findViewById(R.id.textView);
        speakBtn = (Button)v.findViewById(R.id.speakBtn);

        dbh = new DatabaseHelper(context);
        //dbh.deleteTable();
        dbh.createTable();
        List<Sentence> info = new Sentences().getInfo();
        Log.d("Tap2 : ", "database size : " + dbh.dbSize() + " vs. sentence size " + info.size());
        if(dbh.dbSize() == 0) {
            for( Sentence s : info ){
                if( !dbh.exists(s)) {
                    dbh.addSentence(s);
                }
            }
        }

        this.loadSpinnerLanguage();
        this.loadSpinnerCategory(language.getSelectedItem().toString());
        this.loadListViewData(language.getSelectedItem().toString(), category.getSelectedItem().toString());

        language.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadSpinnerCategory(language.getSelectedItem().toString());
                loadListViewData(language.getSelectedItem().toString(), category.getSelectedItem().toString());
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadListViewData( language.getSelectedItem().toString(), category.getSelectedItem().toString());
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        speakBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Locale locale;
                String outputStr = outputTxt.getText().toString();
                String tempLang = language.getSelectedItem().toString();
                try {
                    if (tempLang.equalsIgnoreCase("FRENCH")) {
                        //locale = new Locale("th", "TH");
                        tts.setLanguage(Locale.FRANCE);
                        tts.speak(outputStr, TextToSpeech.QUEUE_ADD, null);
                    } else if (tempLang.equalsIgnoreCase("GERMAN")) {
                        tts.setLanguage(Locale.GERMAN);
                        tts.speak(outputStr, TextToSpeech.QUEUE_ADD, null);
                    } else if (tempLang.equalsIgnoreCase("VIETNAMESE")) {
                        locale = new Locale("vi", "VI");
                        tts.setLanguage(locale);
                        tts.speak(outputStr, TextToSpeech.QUEUE_ADD, null);
                    } else if (tempLang.equalsIgnoreCase("SPANISH")) {
                        locale = new Locale("spa", "MEX");
                        tts.setLanguage(locale);
                        tts.speak(outputStr, TextToSpeech.QUEUE_ADD, null);
                    } else {
                        tts.setLanguage(Locale.US);
                        tts.speak(outputStr, TextToSpeech.QUEUE_ADD, null);
                    }

                } catch (Exception e) {
                    Log.i("Erro in translation...", e.toString());
                }
            }
        });

        tts = new TextToSpeech(context.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS) {
                    int result = tts.setLanguage(Locale.GERMAN);
                    if ( result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.i("TTS", "This language is not support");
                    }else {
                        Log.i("TTS", "This language is supported");
                    }
                }
            }
        });

        return v;
    }

    public void refresh() {
        String lan = language.getSelectedItem().toString();
        String cat = category.getSelectedItem().toString();
        loadSpinnerLanguage();
        if (lan != null && cat != null) {
            this.loadListViewData(lan, cat);
        }
        loadSpinnerCategory(lan);
    }

    private  void loadListViewData(String lan, String cat) {
        List<Sentence> sentences = dbh.getAllSentencesByLanCat(lan, cat);
        ArrayList<String> list = new ArrayList<String>();
        final HashMap<Integer,String> translatedText = new HashMap<>();
        for( int i = 0; i < sentences.size(); i++) {
            Sentence s = sentences.get(i);
            translatedText.put(i, s.getTranslated());
            list.add(s.getOriginal());
        }


        final StableArrayAdapter adapter = new StableArrayAdapter(this.getActivity(),
                android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {

                //final String item = (String) parent.getItemAtPosition(position);
                view.animate().setDuration(500).alpha(0).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        adapter.notifyDataSetChanged();
                        view.setAlpha(1);
                        outputTxt.setText(translatedText.get(position));
                        Toast.makeText(context.getApplicationContext(), translatedText.get(position), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void loadSpinnerLanguage() {
        List<String> list = dbh.getAllLanguages();
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_spinner_item,list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        language.setAdapter(dataAdapter);
    }

    private  void loadSpinnerCategory(String lan) {
        List<String> list = dbh.getAllCategoriesByLan(lan);
        list.add("None");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this.getActivity(),android.R.layout.simple_spinner_item,list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        category.setAdapter(dataAdapter);
    }
}
