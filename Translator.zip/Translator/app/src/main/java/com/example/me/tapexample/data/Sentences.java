package com.example.me.tapexample.data;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by Me on 10/6/2015.
 */
public class Sentences {

    public Sentences(){}
    List<Sentence> info = new LinkedList<>();

    public List<Sentence> getInfo() {

        //GERMAN
        info.add(new Sentence("GERMan", "Restaurant", "I am hungry", "Ich bin hungrig"));
        info.add(new Sentence("GERMAN", "Restaurant", "A table for [two/three/four], please.", "Einen Tisch für [zwei/drei/vier], bitte."));
        info.add(new Sentence("GERMAN", "Restaurant", "I reserved a table.", "Ich habe einen Tisch reserviert."));
        info.add(new Sentence("GERMAN", "Restaurant", "Can I see the [menu/wine list], please?", "Kann ich bitte die [Speisekarte/Weinkarte] sehen? "));
        info.add(new Sentence("GERMAN", "Restaurant", "I would like…", "Ich hätte gern…"));
        info.add(new Sentence("GERMAN", "Restaurant", "What’s the difference between X and Y?", "Was ist die Unterschied zwischen X und Y? "));
        info.add(new Sentence("GERMAN", "Restaurant", "With lactose-free milk, please.", "Mit laktosefreier Milch, bitte. "));
        info.add(new Sentence("GERMAN", "Restaurant", "Do you have vegetarian food?", "Haben Sie vegetarisches Essen?"));
        info.add(new Sentence("GERMAN", "Restaurant", "A glass of water, please.", "Ein Glas Wasser, bitte."));
        info.add(new Sentence("GERMAN", "Restaurant", "Another one, please!", "Noch eins, bitte!"));

        info.add(new Sentence("GERMAN", "Restaurant", "Can I have a receipt, please?", "Kann ich eine Quittung haben, bitte? "));
        info.add(new Sentence("GERMAN", "Supermarket", "How much does it cost?", "Wie viel kostet es?"));
        info.add(new Sentence("GERMAN", "Supermarket", "Do you have souvenirs?", "Haben Sie Andenken?"));
        info.add(new Sentence("GERMAN", "Supermarket", "I can only pay X euros.", "Ich kann nur X Euro bezahlen."));
        info.add(new Sentence("GERMAN", "Supermarket", "Do you have something cheaper?","Habe Sie was billigerer?"));
        info.add(new Sentence("GERMAN", "Supermarket", "Can I pay with cash?", "Kann ich mit Bargeld bezahlen?"));
        info.add(new Sentence("GERMAN", "Supermarket", "Can I pay with credit card?","Kann ich mit Kreditkarte bezahlen?"));
        info.add(new Sentence("GERMAN", "Supermarket", "What time does the shop [open/close]?", "Um wieviel Uhr [öffnet/schließt] das Geschäft?"));
        info.add(new Sentence("GERMAN", "Direction", "Where?", "Wo?"));
        info.add(new Sentence("GERMAN", "Direction", "Excuse me, where is ...?", "Entschuldigung, wo ist ...?"));

        info.add(new Sentence("GERMAN", "Direction", "In what derection is X?", "In welche Richtung ist X?"));
        info.add(new Sentence("GERMAN", "Direction", "Is it near?", "Ist ex in der Nähe?"));
        info.add(new Sentence("GERMAN", "Direction", "Please bring me to this address.", "Bitte bringen Sie mich zu dieser Adresse. "));
        info.add(new Sentence("GERMAN", "Direction", "To the city center, please.", "Zum Stadtzentrum, bitte."));
        info.add(new Sentence("GERMAN", "Direction", "To the train station, please.", "Zum Bahnhof, bitte."));
        info.add(new Sentence("GERMAN", "Direction", "To the airport, please.", "Zum Flughafen, bitte."));
        info.add(new Sentence("GERMAN", "Socialize", "I don’t understand.", "Ich verstehe nicht."));
        info.add(new Sentence("GERMAN", "Socialize", "Please repeat.", "Bitte wiederholen Sie."));
        info.add(new Sentence("GERMAN", "Socialize", "Do you speak English?", "Sprechen Sie Englisch? "));
        info.add(new Sentence("GERMAN", "Socialize", "I don’t speak much GERMAN.", "Ich spreche nicht viel Deutsch. "));

        info.add(new Sentence("GERMAN", "Socialize", "Can you translate that please?", "Können Sie das übersetzen? "));
        info.add(new Sentence("GERMAN", "Socialize", "How are you?", "Wie geht es dir?"));
        info.add(new Sentence("GERMAN", "Socialize", "I am well.", "Mir geht es gut"));
        info.add(new Sentence("GERMAN", "Socialize", "I am not so well.", "Mir geht es nicht so gut"));
        info.add(new Sentence("GERMAN", "Socialize", "Everything alright?", "Alles is Ordnung?"));
        info.add(new Sentence("GERMAN", "Socialize", "You look great!", "Du siehst toll aus!"));
        info.add(new Sentence("GERMAN", "Socialize", "Can I help?", "Kann ich helfen?"));
        info.add(new Sentence("GERMAN", "Socialize", "That is very nice.", "Das ist sehr nett."));
        info.add(new Sentence("GERMAN", "Socialize", "That is fun.", "Das macht Spaß"));
        info.add(new Sentence("GERMAN", "Socialize", "Thanks a lot", "Danke schön"));

        info.add(new Sentence("GERMAN", "Airport", "When do I have to be at the gate?", "Wann muß ich am Gate sein?"));
        info.add(new Sentence("GERMAN", "Airport", "How long is the flight?", "Wie lange ist der Flug?"));
        info.add(new Sentence("GERMAN", "Airport", "How long is the layover?", "Wie lange ist der Zwischenstop?"));
        info.add(new Sentence("GERMAN", "Airport", "Will you serve a hot meal?", "Werden Sie eine warme Mahlzeit servieren?"));
        info.add(new Sentence("GERMAN", "Airport", "Is the flight very busy?", "Ist der Flug sehr voll?"));
        info.add(new Sentence("GERMAN", "Airport", "Do I need a visa?", "Brauche ich ein Visum?"));
        info.add(new Sentence("GERMAN", "Airport", "How long is the visa valid for?", "Wie lange ist das Visum gültig?"));
        info.add(new Sentence("GERMAN", "Airport", "How many pieces of luggage can I take?", "Wie viele Gepäckstücke kann ich mitnehmen?"));
        info.add(new Sentence("GERMAN", "Airport", "How long is the visa valid for?", "Wie lange ist das Visum gültig?"));
        info.add(new Sentence("GERMAN", "Airport", "How many pieces of luggage can I take?", "Wie viele Gepäckstücke kann ich mitnehmen?"));

        info.add(new Sentence("French", "Basic Phrases", "Thank you.", "Merci"));
        info.add(new Sentence("French", "Basic Phrases", "Thank you very much.", "Merci beaucoup."));
        info.add(new Sentence("French", "Basic Phrases", "You are welcome", "De rien"));
        info.add(new Sentence("French", "Basic Phrases", "Please", "S’il vous plaît."));
        info.add(new Sentence("French", "Basic Phrases", "Yes.", "Oui."));
        info.add(new Sentence("French", "Basic Phrases", "Excuse me", "Excusez-moi"));
        info.add(new Sentence("French", "Basic Phrases", "Sorry!", "Excusez-moi!"));
        info.add(new Sentence("French", "Basic Phrases", "I do not understand.", "Je ne comprends pas."));
        info.add(new Sentence("French", "Basic Phrases", "I do not speak French.", "Je ne parle pas français."));
        info.add(new Sentence("French", "Basic Phrases", "Do you speak English?", "Parlez-vous anglais?"));

        info.add(new Sentence("French", "Basic Phrases", "Could you speak more slowly, please?", "Pourriez-vous parler plus lentement, s’il vous plaît?"));
        info.add(new Sentence("French", "Basic Phrases", "What is your name?", "Comment vous appelez-vous?"));
        info.add(new Sentence("French", "Basic Phrases", "How are you?", "Comment allez-vous?"));
        info.add(new Sentence("French", "Basic Phrases", "Where is the bathroom?", "Où sont les toilettes?"));
        info.add(new Sentence("French", "Restaurant", "Have you chosen?", "Avez-vous choisi ?"));
        info.add(new Sentence("French", "Restaurant", "I am listening.", "Je vous écoute."));
        info.add(new Sentence("French", "Restaurant", "What would you like to drink?", "Qu’est-ce que vous voulez comme boisson ?"));
        info.add(new Sentence("French", "Restaurant", "What will you have to drink?", "Qu’est-ce que vous buvez ? "));
        info.add(new Sentence("French", "Restaurant", "I am going to take…", "Je vais prendre…"));
        info.add(new Sentence("French", "Restaurant", "rare", "Rosé"));

        info.add(new Sentence("French", "Restaurant", "medium rare", "À point"));
        info.add(new Sentence("French", "Restaurant", "slightly more cooked", "saignant"));
        info.add(new Sentence("French", "Restaurant", "well done", "bien joué"));
        info.add(new Sentence("French", "Restaurant", "Have you finished?", "Vous avez terminé ?"));
        info.add(new Sentence("French", "Restaurant", "Did you enjoy your meal?", "Ça vous a plu ?"));
        info.add(new Sentence("French", "Restaurant", "Would you like dessert or coffee?", "Vous désirez un dessert ou un café ? "));
        info.add(new Sentence("French", "Airport", "When is the next flight to Marseille?", "A quelle heure est le prochain vol pour Marseille?"));
        info.add(new Sentence("French", "Airport", "I want to confirm my flight.", "Je voudrais confirmer ma réservation sur le vol."));
        info.add(new Sentence("French", "Airport", "What time should I check in?", "L enregistrement est à quelle heure?"));
        info.add(new Sentence("French", "Airport", "What time does the plane take off?", "L avion part à quelle heure?"));

        info.add(new Sentence("French", "Airport", "When does it arrive?", "Il arrive à quelle heure?"));
        info.add(new Sentence("French", "Airport", "Is there a bus to the airport?", "Est-ce qu il y a un bus pour l aéroport?"));
        info.add(new Sentence("French", "Airport", "As soon as possible", "Le plus tôt possible"));
        info.add(new Sentence("French", "Airport", "Departure", "Départ"));
        info.add(new Sentence("French", "Shopping", "How much does that cost?", "Combien ça coûte?"));
        info.add(new Sentence("French", "Shopping", "I would like to pay in cash.", "Je voudrais payer en liquide."));
        info.add(new Sentence("French", "Shopping", "I would like (to buy) this.", "Je vais prendre ceci."));
        info.add(new Sentence("French", "Shopping", "A packet of..., please.", "Un paquet de..., s il vous plaît."));
        info.add(new Sentence("French", "Shopping", "Do you have...?", "Est-ce que vous avez...?"));
        info.add(new Sentence("French", "Shopping", "Do you take credit cards?", "Est-ce que vous acceptez les cartes de crédit?"));

         //spanish
        info.add(new Sentence("Spanish","Greetings", "Hello!", "¡Hola!"));
        info.add(new Sentence("Spanish","Greetings", "Good morning!", "¡Buenos días!"));
        info.add(new Sentence("Spanish","Greetings", "Good day!", "¡Buen día!"));
        info.add(new Sentence("Spanish","Greetings", "How are you?", "¿Cómo está?"));
        info.add(new Sentence("Spanish","Greetings",  "What is your name?", "¿Cómo se llama?"));
        info.add(new Sentence("Spanish","Greetings", "It is nice to meet you.", "Mucho gusto."));
        info.add(new Sentence("Spanish","Greetings",  "This is my friend.", "Éste es mi amigo."));
        info.add(new Sentence("Spanish","Greetings", "I had a wonderful time.", "Lo pasé de maravilla."));
        info.add(new Sentence("Spanish","Greetings",  "Where do you live?", "¿Dónde vive?"));
        info.add(new Sentence("Spanish","Greetings",  "Goodbye.", "Adiós."));

        info.add(new Sentence("Spanish", "Directions", "Where?", "¿Dónde?"));
        info.add(new Sentence("Spanish", "Directions", "Excuse me, where is…?", "¿Disculpe, dónde está…?"));
        info.add(new Sentence("Spanish", "Directions", "Where are the taxis?", "¿Dónde están los taxis?"));
        info.add(new Sentence("Spanish", "Directions", "Where is the bus?", "¿Por dónde pasa el autobús?"));
        info.add(new Sentence("Spanish", "Directions", "Where is the subway?", "¿Dónde está el metro?"));
        info.add(new Sentence("Spanish", "Directions", "Where is the exit?", "¿Dónde está la salida?"));
        info.add(new Sentence("Spanish", "Directions", "Is it near?", "¿Está cerca?"));
        info.add(new Sentence("Spanish", "Directions", "Is it far?", "¿Está lejos?"));
        info.add(new Sentence("Spanish", "Directions", "Take me to this address, please.", "Lléveme a esta dirección, por favor."));
        info.add(new Sentence("Spanish", "Directions", "What is the fare?", "¿Cuánto es la tarifa?"));

        info.add(new Sentence("Spanish", "Directions", "Stop here, please.", "¿Pasa este autobús por la calle de los Conquistadores?"));
        info.add(new Sentence("Spanish", "Directions", "Does this bus go to Conquistadores Street?", ""));
        info.add(new Sentence("Spanish", "Directions", "A map of the city, please.", "Un plano de la ciudad, por favor."));
        info.add(new Sentence("Spanish", "Directions", "A subway map, please.", "Un plano del metro, por favor."));
        info.add(new Sentence("Spanish", "Shopping", "How much does that cost?", "¿Cuánto cuesta?"));
        info.add(new Sentence("Spanish", "Shopping", "At what time does the store open?", "¿A qué hora abre la tienda?"));
        info.add(new Sentence("Spanish", "Shopping", "At what time does the store close?", "¿A qué hora cierra la tienda?"));
        info.add(new Sentence("Spanish", "Shopping", "What would you like?", "¿Qué está buscando?"));
        info.add(new Sentence("Spanish", "Shopping", "Can I help you?", "¿Necesita alguna ayuda?"));
        info.add(new Sentence("Spanish", "Shopping", "I would like this.", "Necesito esto."));

        info.add(new Sentence("Spanish", "Shopping", "I would like to pay in cash.", "Me gustaría pagar en efectivo."));
        info.add(new Sentence("Spanish", "Shopping", "I would like to pay by credit card.", "Me gustaría pagar con tarjeta de crédito."));
        info.add(new Sentence("Spanish", "Shopping", "Can I order this online?", "¿Puedo ordenar esto por el internet?"));
        info.add(new Sentence("Spanish", "Shopping", "jeans", "vaqueros"));
        info.add(new Sentence("Spanish", "Shopping", "bookstore", "librería"));
        info.add(new Sentence("Spanish", "Shopping", "bakery", "panadería"));
        info.add(new Sentence("Spanish", "Shopping", "supermarket", "supermercado"));
        info.add(new Sentence("Spanish", "Restaurant", "Where is a good restaurant?", "¿Me recomienda algún restaurante?"));
        info.add(new Sentence("Spanish", "Restaurant", "A table for two, please.", "Una mesa para dos, por favor."));
        info.add(new Sentence("Spanish", "Restaurant", "The menu, please.", "La carta, por favor."));

        info.add(new Sentence("Spanish", "Restaurant", "The wine list, please.", "La lista de vinos, por favor."));
        info.add(new Sentence("Spanish", "Restaurant", "I would like something to drink.", "Quisiera algo para beber."));
        info.add(new Sentence("Spanish", "Restaurant", "A glass of water, please.", "Un vaso de agua, por favor."));
        info.add(new Sentence("Spanish", "Restaurant", "A cup of tea. please.", "Un té, por favor."));
        info.add(new Sentence("Spanish", "Restaurant", "Do you have a vegetarian dish?", "¿Tiene algún plato vegetariano?"));
        info.add(new Sentence("Spanish", "Restaurant", "The check, please.", "La cuenta, por favor."));
        info.add(new Sentence("Spanish", "Restaurant", "I like my steak rare.", "Quisiera la carne poco cocida."));
        info.add(new Sentence("Spanish", "Restaurant", "I like my steak medium.", "Quisiera la carne a medio cocer."));
        info.add(new Sentence("Spanish", "Restaurant", "I like my steak well done.", "Quisiera la carne bien cocida."));
        info.add(new Sentence("Spanish", "Restaurant", "More, please.", "Más, por favor."));

         //vietnamese
        info.add(new Sentence("Vietnamese", "Basic Phrases", "Hello!", "Xin chào!"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "Goodbye", "Tam Biet"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "How are you?", "Bạn có khỏe không?"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "I am fine, thank you! ", "Cam on ban toi khoe"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "What is your name?", "Bạn tên gì?"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "My name is...", "Tôi tên là ..."));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "Thank you", "Xin Cam on"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "You are welcome", "Khong co gi"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "Yes", "Vang"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "No", "Khong"));

        info.add(new Sentence("Vietnamese", "Basic Phrases", "I am happy", "Tôi vui"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "I am tired ", "Tôi met "));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "Excuse me", "Xin loi"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "Can you help me?", "Ban giup toi duoc khong?"));
        info.add(new Sentence("Vietnamese", "Basic Phrases", "What is this?", "Cai nay la gi"));
        info.add(new Sentence("Vietnamese", "Restaurant", "I would like to eat", "Tôi thích ăn"));
        info.add(new Sentence("Vietnamese", "Restaurant", "I would like to drink", "Tôi muon uong"));
        info.add(new Sentence("Vietnamese", "Restaurant", "Hot black coffee", "Ca phe nong"));
        info.add(new Sentence("Vietnamese", "Restaurant", "Hot Coffee with milk", "Ca phe sua nong"));
        info.add(new Sentence("Vietnamese", "Restaurant", "Too expensive", "Mac qua"));

        info.add(new Sentence("Vietnamese", "Shopping", "Where is Ben Thanh market?", "Chợ Bến Thành ở đâu?"));
        info.add(new Sentence("Vietnamese", "Shopping", "Where can I buy sun cream?", "Tôi có thể mua kem chống nắng ở đâu?"));
        info.add(new Sentence("Vietnamese", "Shopping", "How much is it?", "Bao nhiêu tiền?"));
        info.add(new Sentence("Vietnamese", "Shopping", "It is too expensive", "Mắc quá"));
        info.add(new Sentence("Vietnamese", "Shopping", "Do you have something cheaper?", "Bạn có cái nào rẻ hơn không?"));
        info.add(new Sentence("Vietnamese", "Shopping", "Can I pay by card?", "Tôi có thể trả bằng thẻ tín dụng không?"));
        info.add(new Sentence("Vietnamese", "Shopping", "It is perfect", "Rất tốt"));
        info.add(new Sentence("Vietnamese", "Shopping", "Do you have a smaller one?", "Bạn có cái nhỏ hơn không?"));
        info.add(new Sentence("Vietnamese", "Shopping", "Do you have a bigger one?", "Bạn có cái lớn hơn không?"));
        info.add(new Sentence("Vietnamese", "Shopping", "Can I try it?", "Tôi có thể thử nó được không?"));

        info.add(new Sentence("Vietnamese", "Restaurant", "I am a vegetarian", "Tôi ăn chay"));
        info.add(new Sentence("Vietnamese", "Restaurant", "Can I have the bill please?", "Tính tiền"));
        info.add(new Sentence("Vietnamese", "Restaurant", "I am full", "Tôi no rồi"));
        info.add(new Sentence("Vietnamese", "Restaurant", "Can I have the menu please?", "Có thực đơn không?"));
        info.add(new Sentence("Vietnamese", "Restaurant", "Can I have chicken sate please", "Tôi muốn gà sa tế"));
        info.add(new Sentence("Vietnamese", "Restaurant", "Can I have a glass of red wine please?", "Tôi muốn một ly rượu đỏ"));
        info.add(new Sentence("Vietnamese", "Telling time", "What time is it?", "Mấy giờ rồi?"));
        info.add(new Sentence("Vietnamese", "Telling time", "It is 1 oclock.", "Một giờ rồi"));
        info.add(new Sentence("Vietnamese", "Telling time", "Now it is ten past three", "Bây Giờ là ba giờ mười phút"));
        info.add(new Sentence("Vietnamese", "Telling time", "Breakfast is between 7 and 9 am", "Ăn sáng từ bảy giờ đến 9 giờ"));

        info.add(new Sentence("Vietnamese", "Telling time", "How long?", "Bao Lâu?"));
        info.add(new Sentence("Vietnamese", "Telling time", "How long have you been in Vietnam?", "Bạn ở Việt Nam bao lâu?"));
        info.add(new Sentence("Vietnamese", "Telling time", "When will you go home?", "Khi nào đi về nhà?"));
        info.add(new Sentence("Vietnamese", "Telling time", "I am in Vietnam until March", "Tôi ở Việt Nam đến tháng Ba"));
        info.add(new Sentence("Vietnamese", "Telling time", "I have been in Vietnam 2 weeks already", "Tôi ở Việt Nam hai tuần rồi."));
        info.add(new Sentence("Vietnamese", "Making friends", "It is lovely to meet you", "Rất vui được gặp bạn."));
        info.add(new Sentence("Vietnamese", "Making friends", "Where are you from?", "Bạn từ đâu đến?"));
        info.add(new Sentence("Vietnamese", "Making friends", "Do you have any brothers or sisters?", "Bạn có anh chị em không?"));
        info.add(new Sentence("Vietnamese", "Making friends", "How many people are there in your family?", "Có bao nhiêu người trong gia đình bạn?"));
        info.add(new Sentence("Vietnamese", "Making friends", "See you later", "Hẹn gặp lại"));
        return info;
    }
}

