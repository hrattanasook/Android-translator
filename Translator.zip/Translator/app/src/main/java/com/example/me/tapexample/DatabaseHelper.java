package com.example.me.tapexample;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.me.tapexample.data.Sentence;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Me on 9/30/2015.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    // Database Name
    public static final String DATABASE_NAME = "TextManager.db";
    // Contacts table name
    public static final String TABLE_SENTENCE = "sentence";
    // Contacts Table Columns names
    public static final String KEY_ID = "id";
    public static final String KEY_LANGUAGE = "language";
    public static final String KEY_CATEGORY = "category";
    public static final String KEY_ORIGINAL = "original";
    public static final String KEY_TRANSLATE = "translate";
    SQLiteDatabase db;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public void createTable() {
        db = this.getWritableDatabase();
        String CREATE_LIST_SENTENCE_TABLE = "CREATE TABLE IF NOT EXISTS " + TABLE_SENTENCE + " ( " // " IF NOT EXISTS ("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_LANGUAGE + " TEXT,"
                + KEY_CATEGORY + " TEXT,"
                + KEY_ORIGINAL + " TEXT,"
                + KEY_TRANSLATE + " TEXT" + " )";

        db.execSQL(CREATE_LIST_SENTENCE_TABLE);
        onCreate(db);
        db.close();
    }

    public void deleteTable() {
        db = this.getWritableDatabase();
        db.execSQL("DROP TABLE " + TABLE_SENTENCE);
        db.close();
    }

    public int dbSize() {
        db = this.getReadableDatabase();
        List<String> data = new ArrayList<String>();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_SENTENCE, null);
        while (c.moveToNext()) {
            data.add(c.getString(1));
        }
        c.close();
        db.close();
        return data.size();
    }

    public List<Sentence> remove( int i ) {
        db = this.getReadableDatabase();
        List<Sentence> data = new ArrayList<>();
        Cursor c = db.rawQuery("DELETE FROM " + TABLE_SENTENCE + " WHERE " + KEY_ID +"="+ i, null);
        while (c.moveToNext()) {
            Sentence sentence = new Sentence();
            sentence.setId(Integer.parseInt(c.getString(0)));
            sentence.setLanguage(c.getString(1));
            sentence.setCategory(c.getString(2));
            sentence.setOriginal(c.getString(3));
            sentence.setTranslated(c.getString(4));
            // Adding contact to list
            data.add(sentence);
        }
        c.close();
        db.close();
        return data;
    }

    public boolean exists(Sentence s) {
        String query = "SELECT COUNT(*) FROM "
                + TABLE_SENTENCE
                + " WHERE "
                + KEY_LANGUAGE + " = '" + s.getLanguage() + "' AND "
                + KEY_TRANSLATE + " = '" + s.getTranslated() + "' AND "
                + KEY_ORIGINAL + " = '" + s.getOriginal() + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        int count = 0;
        if ( cursor.moveToFirst() ) {
            count = cursor.getInt(0);
        }
        return count > 0;
    }

    // Getting All Text
    public List<Sentence> getAllSentences() {
        List<Sentence> sentenceList = new ArrayList<Sentence>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_SENTENCE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Sentence sentence = new Sentence();
                sentence.setId(Integer.parseInt(cursor.getString(0)));
                sentence.setLanguage(cursor.getString(1));
                sentence.setCategory(cursor.getString(2));
                sentence.setOriginal(cursor.getString(3));
                sentence.setTranslated(cursor.getString(4));
                // Adding contact to list
                sentenceList.add(sentence);
            } while (cursor.moveToNext());
        }
        // return contact list
        return sentenceList;
    }

    // Adding new contact
    void addSentence (Sentence sentence) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_LANGUAGE, sentence.getLanguage()); // Sentence language
        values.put(KEY_CATEGORY, sentence.getCategory()); // Sentence category
        values.put(KEY_ORIGINAL, sentence.getOriginal()); // sentence text
        values.put(KEY_TRANSLATE, sentence.getTranslated());

        // Inserting Row
        db.insert(TABLE_SENTENCE, null, values);
        db.close(); // Closing database connection
    }

    public List<Sentence> getAllSentencesByLanCat(String language, String category) {
        List<Sentence> sentenceList = new ArrayList<Sentence>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_SENTENCE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Sentence sentence = new Sentence();

                if( cursor.getString(1).equalsIgnoreCase(language)
                        && (cursor.getString(2).equalsIgnoreCase(category)
                            || category.equalsIgnoreCase("None"))) {
                    sentence.setId(Integer.parseInt(cursor.getString(0)));
                    sentence.setLanguage(cursor.getString(1));
                    sentence.setCategory(cursor.getString(2));
                    sentence.setOriginal(cursor.getString(3));
                    sentence.setTranslated(cursor.getString(4));
                    // Adding contact to list
                    sentenceList.add(sentence);
                }
            } while (cursor.moveToNext());
        }
        // return contact list
        return sentenceList;
    }

    public List<Sentence> getSentencesByLan (String lan) {
        List<Sentence> sentenceList = new ArrayList<Sentence>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_SENTENCE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Sentence sentence = new Sentence();

                if( cursor.getString(1).equalsIgnoreCase(lan)) {
                    sentence.setId(Integer.parseInt(cursor.getString(0)));
                    sentence.setLanguage(cursor.getString(1));
                    sentence.setCategory(cursor.getString(2));
                    sentence.setOriginal(cursor.getString(3));
                    sentence.setTranslated(cursor.getString(4));
                    // Adding contact to list
                    sentenceList.add(sentence);
                }
            } while (cursor.moveToNext());
        }
        // return contact list
        return sentenceList;
    }


    public List<String> getAllCategoriesByLan(String lan) {
        List<String> categories = new ArrayList<>();
        String selectQuery = "SELECT DISTINCT " + KEY_CATEGORY
                + " FROM " + TABLE_SENTENCE
                + " WHERE " + KEY_LANGUAGE
                + " = '" + lan + "' COLLATE NOCASE";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String cate = cursor.getString(0);
                if( cate.length() > 0) {
                    categories.add(cate);
                }
            } while (cursor.moveToNext());
        }
        // return contact list
        return categories;
    }

    public List<String> getAllLanguages() {
        List<String> categories = new ArrayList<>();
        String selectQuery = "SELECT DISTINCT Upper(" + KEY_LANGUAGE + ")"
                + " FROM " + TABLE_SENTENCE;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                String cate = cursor.getString(0);
                if( cate.length() > 0) {
                    categories.add(cate.toUpperCase());
                }
            } while (cursor.moveToNext());
        }
        // return contact list
        return categories;
    }

}
