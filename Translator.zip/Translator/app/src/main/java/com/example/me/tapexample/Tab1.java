package com.example.me.tapexample;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.memetix.mst.language.Language;
import com.memetix.mst.translate.Translate;

import java.util.Locale;

/**
 * Created by Me on 9/23/2015.
 */
public class Tab1 extends Fragment implements ITab, View.OnClickListener, TextToSpeech.OnInitListener {
    View v;
    Button translateBtn;
    Button txt2SpchBtn;
    EditText inputEt;
    TextView translatedTv;

    String inputStr = null;
    String translatedStr = null;
    String langSelected = null;
    TextToSpeech ttspch;

    Spinner lang;
    int check_code = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v =inflater.inflate(R.layout.tab_1,container,false);

        translateBtn = (Button)v.findViewById(R.id.bTranslate);
        translateBtn.setOnClickListener(this);
        inputEt = (EditText)v.findViewById(R.id.etUserText);
        translatedTv = (TextView)v.findViewById(R.id.tvTranslatedText);
        lang = (Spinner)v.findViewById(R.id.selectLanguage);

        // text to speech
        txt2SpchBtn = (Button)v.findViewById(R.id.bSpeak);
        txt2SpchBtn.setOnClickListener(this);
        Intent check = new Intent();
        check.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(check, check_code);

        ttspch = new TextToSpeech(getContext(), this);

        return v;
    }

    @Override
    public void refresh() { }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.bTranslate:
                    inputStr = inputEt.getText().toString();
                    langSelected = lang.getSelectedItem().toString();

                    new MyAsyncTask(){
                        protected void onPostExecute(Boolean result) {
                            translatedTv.setText(translatedStr);
                        }
                    }.execute();
                break;
            case R.id.bSpeak:
                //Toast.makeText(getApplicationContext(), translatedStr, Toast.LENGTH_SHORT).show();
                Locale locale;
                try {
                    if( langSelected.equalsIgnoreCase("FRENCH"))
                    {
                        ttspch.setLanguage(Locale.FRANCE);
                        ttspch.speak(translatedStr, TextToSpeech.QUEUE_ADD, null);
                    }
                    else if(langSelected.equalsIgnoreCase("GERMAN"))
                    {
                        ttspch.setLanguage(Locale.GERMAN);
                        ttspch.speak(translatedStr, TextToSpeech.QUEUE_ADD, null);
                    }
                    else if(langSelected.equalsIgnoreCase("VIETNAMESE"))
                    {
                        locale = new Locale("vi", "VI");
                        ttspch.setLanguage(locale);
                        ttspch.speak(translatedStr, TextToSpeech.QUEUE_ADD, null);
                    }
                    else if(langSelected.equalsIgnoreCase("SPANISH"))
                    {
                        locale = new Locale("spa", "MEX");
                        ttspch.setLanguage(locale);
                        ttspch.speak(translatedStr, TextToSpeech.QUEUE_ADD, null);
                    }

                }catch (Exception e) {
                    Log.i("Erro in translation...", e.toString());
                }
                break;
        }
    }

    @Override
    public void onInit(int status) {
        if(status == TextToSpeech.SUCCESS) {
           // Toast.makeText(MainActivity.this,"Engine is initialised", Toast.LENGTH_LONG).show();
            int result = ttspch.setLanguage(Locale.GERMAN);
            if ( result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.i("TTS", "This language is not support");
            }else {
                Log.i("TTS", "This language is supported");
            }
        }
    }

    class MyAsyncTask extends AsyncTask<Void, Integer, Boolean> {

        @Override
        protected Boolean doInBackground(Void... arg0) {
            Translate.setClientId("kingdomCodeTalker");
            Translate.setClientSecret("oue5Vne0l/gMW8VhtYoIgpOH0gswjexJjxvFFy6Fwl0=");

            try {
                if(langSelected.equalsIgnoreCase("FRENCH"))
                {
                    translatedStr = Translate.execute(inputStr, Language.ENGLISH, Language.FRENCH);
                }
                else if(langSelected.equalsIgnoreCase("GERMAN"))
                {
                    translatedStr = Translate.execute(inputStr, Language.ENGLISH, Language.GERMAN);
                }
                else if(langSelected.equalsIgnoreCase("VIETNAMESE"))
                {
                    translatedStr = Translate.execute(inputStr, Language.ENGLISH, Language.VIETNAMESE);
                }
                else if(langSelected.equalsIgnoreCase("SPANISH"))
                {
                    translatedStr = Translate.execute(inputStr, Language.ENGLISH, Language.SPANISH);
                }

            } catch(Exception e) {
                translatedStr = inputStr;
            }
            return true;
        }
    }
}
